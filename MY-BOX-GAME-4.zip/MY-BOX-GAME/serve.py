#!/usr/bin/env python3
"""Serveur local avec les en-têtes COOP/COEP exigés par le moteur (threads WebAssembly)."""
import http.server, socketserver, sys, mimetypes
mimetypes.add_type('application/wasm', '.wasm')
mimetypes.add_type('text/javascript', '.js')

class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
        self.send_header('Cross-Origin-Embedder-Policy', 'require-corp')
        self.send_header('Cache-Control', 'no-cache')
        super().end_headers()

socketserver.ThreadingTCPServer.allow_reuse_address = True
port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
with socketserver.ThreadingTCPServer(('', port), Handler) as srv:
    print(f'MY BOX_GAME : http://localhost:{port}')
    srv.serve_forever()
