// Ajoute les en-têtes COOP/COEP (isolation cross-origin) et sert le moteur installé depuis le cache.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.cache === 'only-if-cached' && r.mode !== 'same-origin') return;
  const url = new URL(r.url);
  if (url.origin !== location.origin) return;
  e.respondWith((async () => {
    try {
      let res;
      const m = url.pathname.match(/\/assets\/vendor\/emulator\/(mgba\.(?:js|wasm))$/);
      if (m) res = await (await caches.open('mbg-engine')).match('__engine/' + m[1]);
      res ||= await fetch(r);
      if (res.status === 0) return res;
      const h = new Headers(res.headers);
      h.set('Cross-Origin-Opener-Policy', 'same-origin');
      h.set('Cross-Origin-Embedder-Policy', 'require-corp');
      return new Response(res.body, { status: res.status, statusText: res.statusText, headers: h });
    } catch { return Response.error(); }
  })());
});
