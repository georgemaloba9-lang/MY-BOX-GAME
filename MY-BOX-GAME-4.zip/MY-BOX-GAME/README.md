# MY BOX_GAME (étapes 1 à 6)

Interface, bibliothèque locale et intégration du moteur mGBA (WebAssembly).

## 1. Installer le moteur (une seule fois)
Le moteur n'est pas fourni dans ce dossier. Avec Node/npm et internet :

    ./get-engine.sh

Cela copie mgba.js et mgba.wasm (paquet @thenick775/mgba-wasm 2.3.3, mGBA sous licence MPL-2.0)
dans assets/vendor/emulator/. Conservez les fichiers de licence à côté. Si vous distribuez
l'application, la MPL-2.0 impose de laisser accessible le code source des fichiers mGBA
(https://github.com/thenick775/mgba, branche feature/wasm).

## 2. Lancer
    python3 serve.py          # puis http://localhost:8000

Ne pas utiliser « python3 -m http.server » ni file:// : le moteur utilise des threads WebAssembly,
qui exigent les en-têtes Cross-Origin-Opener-Policy: same-origin et Cross-Origin-Embedder-Policy: require-corp.
En ligne, l'hébergeur doit envoyer ces mêmes en-têtes (Netlify, Cloudflare Pages, Nginx... oui ; GitHub Pages seul, non).

## 3. Jouer
Bibliothèque > importer une ROM que vous possédez (.gba ou .zip) > Jouer.
Fonctions de l'étape 3 : lancer, pause/reprendre, son (muet), plein écran, messages d'erreur, fermeture du jeu à la sortie du lecteur.
Les sauvegardes du jeu (.sav) sont écrites par le moteur dans le stockage du navigateur.

## Sur téléphone
Il faut servir le dossier en HTTPS (ou localhost). sw.js ajoute les en-têtes COOP/COEP et la page se recharge une fois au premier chargement.
- Hébergement statique (Cloudflare Pages, Netlify, GitHub Pages) : déposez le contenu du dossier, ouvrez l'adresse sur le téléphone.
- Termux (Android) : pkg install python, dézipper, python3 serve.py, ouvrir http://localhost:8000 dans Chrome.
- Moteur : sans ordinateur, ouvrez un jeu puis touchez « Installer le moteur » (télécharge mgba.js et mgba.wasm depuis unpkg et les garde dans le navigateur).

## Étape 4 : commandes
Tactile (croix, A, B, L, R, Start, Select, multi-doigts, déplaçables, taille et transparence réglables) et manette (Gamepad API, test, correspondance modifiable).

## Étape 5 : paramètres
Thème, son (coupé/volume), vitesse 1×/1,5×/2×/3× (multiplicateur du moteur, aussi via le bouton Vitesse du lecteur), taille/transparence/positions des boutons, rendu de l'image. Tout est mémorisé.

## Étape 6 : sauvegardes
La sauvegarde du jeu (.sav) est copiée automatiquement dans notre base (IndexedDB) pendant et à la fin d'une partie. La sauvegarde rapide (état complet) se fait depuis l'écran de jeu. La page Sauvegardes permet de reprendre, exporter, importer et supprimer (avec confirmation).

## Créer une application Android (APK) avec GitHub, sans hébergement
1. Créez un dépôt GitHub, envoyez MY-BOX-GAME.zip (Add file > Upload files).
2. Add file > Create new file : nom .github/workflows/build-apk.yml, collez le contenu de build-apk.yml, Commit.
3. Onglet Actions > Build APK > Run workflow. Attendre quelques minutes.
4. Dans l'exécution terminée, section Artifacts : MY-BOX-GAME-apk (un zip contenant app-debug.apk). Installez l'APK (autoriser les sources inconnues).
Le moteur est intégré à l'APK par le workflow.

## Jouer sur téléphone : GitHub Pages (recommandé)
L'APK (Android WebView) ne peut pas fournir l'isolation cross-origin dont le moteur a besoin. Utilisez Chrome :
1. Dépôt GitHub : Settings > Pages > Source : GitHub Actions.
2. Ajoutez pages.yml dans .github/workflows/, gardez un seul zip dans le dépôt.
3. Actions > Publier sur GitHub Pages > Run workflow. L'adresse apparaît à la fin : https://<compte>.github.io/<dépôt>/
4. Ouvrez-la dans Chrome (elle se recharge une fois), puis menu > Ajouter à l'écran d'accueil.

## Pas encore faits
Rien d'obligatoire ; points à tester sur appareil (voir ci-dessus).
Au clavier, le moteur utilise ses touches par défaut.
