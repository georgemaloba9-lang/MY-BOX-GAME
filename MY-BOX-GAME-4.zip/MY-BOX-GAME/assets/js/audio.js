import { storage } from './storage.js';
import * as emu from './emulator.js';

export const getAudio = () => ({ volume: storage.get('volume', 80), muted: storage.get('muted', false) });
export function applyAudio() { const a = getAudio(); emu.setVolume(a.muted ? 0 : a.volume); }
export function setMuted(m) { storage.set('muted', m); applyAudio(); }
export function toggleMute() { const m = !getAudio().muted; setMuted(m); return m; }
export function setVolumeLevel(v) { storage.set('volume', v); applyAudio(); }
