const P = 'mbg:';
export const storage = {
  get(key, fallback = null) {
    try { const v = localStorage.getItem(P + key); return v === null ? fallback : JSON.parse(v); }
    catch { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem(P + key, JSON.stringify(value)); return true; }
    catch { return false; }
  }
};

// IndexedDB : métadonnées des jeux (games), fichiers ROM (roms), sauvegardes (saves, étape 6).
let dbp;
function db() {
  return dbp ||= new Promise((res, rej) => {
    if (!window.indexedDB) return rej(new Error('IndexedDB indisponible'));
    const r = indexedDB.open('mybox', 1);
    r.onupgradeneeded = () => {
      const d = r.result;
      d.createObjectStore('games', { keyPath: 'id' });
      d.createObjectStore('roms');
      d.createObjectStore('saves', { keyPath: 'id' });
    };
    r.onsuccess = () => res(r.result);
    r.onerror = () => { dbp = null; rej(r.error); };
  });
}
const req = r => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const done = t => new Promise((res, rej) => { t.oncomplete = () => res(); t.onerror = t.onabort = () => rej(t.error); });

export const gamesDb = {
  async all() { return req((await db()).transaction('games').objectStore('games').getAll()); },
  async get(id) { return req((await db()).transaction('games').objectStore('games').get(id)); },
  async rom(id) { return req((await db()).transaction('roms').objectStore('roms').get(id)); },
  async add(meta, blob) {
    const t = (await db()).transaction(['games', 'roms'], 'readwrite');
    t.objectStore('games').put(meta);
    t.objectStore('roms').put(blob, meta.id);
    return done(t);
  },
  async update(meta) {
    const t = (await db()).transaction('games', 'readwrite');
    t.objectStore('games').put(meta);
    return done(t);
  },
  // Supprime le jeu et sa ROM. Les sauvegardes (store "saves") ne sont jamais touchées ici.
  async remove(id) {
    const t = (await db()).transaction(['games', 'roms'], 'readwrite');
    t.objectStore('games').delete(id);
    t.objectStore('roms').delete(id);
    return done(t);
  }
};

// Sauvegardes : id = "<idJeu>:save" (sauvegarde du jeu) ou "<idJeu>:quick" (sauvegarde rapide).
export const savesDb = {
  async all() { return req((await db()).transaction('saves').objectStore('saves').getAll()); },
  async get(id) { return req((await db()).transaction('saves').objectStore('saves').get(id)); },
  async put(rec) {
    const t = (await db()).transaction('saves', 'readwrite');
    t.objectStore('saves').put(rec);
    return done(t);
  },
  async remove(id) {
    const t = (await db()).transaction('saves', 'readwrite');
    t.objectStore('saves').delete(id);
    return done(t);
  }
};
