import { storage } from './storage.js';
import * as emu from './emulator.js';

// ---- Mode d'entrée ----
export const getMode = () => storage.get('inputMode', 'auto'); // auto | touch | pad
export const setMode = m => storage.set('inputMode', m);
export const padActive = () => getMode() !== 'touch';
export const touchVisible = () => getMode() === 'touch' || (getMode() === 'auto' && matchMedia('(pointer:coarse)').matches);

// ---- Fusion des sources (tactile, manette) : une touche est enfoncée si au moins une source la tient ----
const held = new Map();
let active = new Set();
function recompute() {
  const u = new Set();
  held.forEach(s => s.forEach(k => u.add(k)));
  u.forEach(k => { if (!active.has(k)) emu.press(k); });
  active.forEach(k => { if (!u.has(k)) emu.release(k); });
  active = u;
}
export function setSourceKeys(src, keys) { keys.size ? held.set(src, keys) : held.delete(src); recompute(); }
export function releaseAll() { held.clear(); recompute(); }

// ---- Commandes tactiles ----
const ORDER = ['dpad', 'l', 'r', 'select', 'start', 'b', 'a'];
const LABEL = { l: 'L', r: 'R', select: 'Select', start: 'Start', a: 'A', b: 'B' };
const DEF = {
  portrait: { dpad: [20, 76], a: [87, 70], b: [72, 80], l: [14, 56], r: [86, 56], select: [38, 94], start: [62, 94] },
  landscape: { dpad: [12, 62], a: [92, 55], b: [84, 74], l: [8, 16], r: [92, 16], select: [42, 92], start: [58, 92] }
};
const orient = () => innerHeight > innerWidth ? 'portrait' : 'landscape';
const clamp = v => Math.max(4, Math.min(96, v));

export function initControls(layer) {
  const st = storage.get('touchCfg', {});
  const cfg = { scale: 1, opacity: 0.7, ...st, pos: { portrait: {}, landscape: {}, ...(st.pos || {}) } };
  const save = () => storage.set('touchCfg', cfg);
  let edit = false;
  const els = {};

  const place = () => {
    const o = orient();
    layer.style.setProperty('--u', 54 * cfg.scale + 'px');
    layer.style.opacity = cfg.opacity;
    for (const k of ORDER) {
      const p = cfg.pos[o][k] || DEF[o][k];
      els[k].style.left = p[0] + '%'; els[k].style.top = p[1] + '%';
    }
  };

  function wire(el, k) {
    const down = new Set();
    const keysFrom = e => {
      if (k !== 'dpad') return new Set([k]);
      const r = el.getBoundingClientRect();
      const dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
      const d = Math.hypot(dx, dy), s = new Set();
      if (d < r.width * 0.12) return s;
      const nx = dx / d, ny = dy / d;
      if (nx > .38) s.add('right'); if (nx < -.38) s.add('left');
      if (ny > .38) s.add('down'); if (ny < -.38) s.add('up');
      return s;
    };
    el.onpointerdown = e => {
      e.preventDefault(); el.setPointerCapture(e.pointerId); down.add(e.pointerId);
      if (!edit) { setSourceKeys('t' + e.pointerId, keysFrom(e)); el.classList.add('on'); }
    };
    el.onpointermove = e => {
      if (!down.has(e.pointerId)) return;
      if (edit) { cfg.pos[orient()][k] = [clamp(e.clientX / innerWidth * 100), clamp(e.clientY / innerHeight * 100)]; place(); }
      else if (k === 'dpad') setSourceKeys('t' + e.pointerId, keysFrom(e));
    };
    const end = e => {
      if (!down.delete(e.pointerId)) return;
      setSourceKeys('t' + e.pointerId, new Set());
      if (!down.size) el.classList.remove('on');
      if (edit) save();
    };
    el.onpointerup = end; el.onpointercancel = end; el.onlostpointercapture = end;
    el.oncontextmenu = e => e.preventDefault();
  }

  layer.replaceChildren();
  for (const k of ORDER) {
    const el = document.createElement('div');
    el.className = 'tbtn t-' + k + (k === 'dpad' ? ' dpad' : '');
    el.setAttribute('role', 'button'); el.setAttribute('aria-label', LABEL[k] || 'Croix directionnelle');
    el.innerHTML = k === 'dpad' ? '<i class="u">▲</i><i class="d">▼</i><i class="l">◀</i><i class="r">▶</i>' : LABEL[k];
    els[k] = el; layer.append(el); wire(el, k);
  }
  addEventListener('resize', place);
  place();

  return {
    cfg,
    setVisible: v => { layer.hidden = !v; },
    setEdit: on => { edit = on; layer.classList.toggle('edit', on); releaseAll(); },
    setScale: v => { cfg.scale = +v; place(); save(); },
    setOpacity: v => { cfg.opacity = +v; place(); save(); },
    reset: () => { cfg.pos = { portrait: {}, landscape: {} }; cfg.scale = 1; cfg.opacity = 0.7; place(); save(); },
    destroy: () => { removeEventListener('resize', place); releaseAll(); }
  };
}
