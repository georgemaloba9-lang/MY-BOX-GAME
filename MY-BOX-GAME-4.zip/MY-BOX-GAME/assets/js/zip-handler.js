let loading;
function loadJSZip() {
  if (window.JSZip) return Promise.resolve(window.JSZip);
  return loading ||= new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = 'assets/vendor/jszip/jszip.min.js';
    s.onload = () => res(window.JSZip);
    s.onerror = () => { loading = null; rej(new Error('JSZip introuvable dans assets/vendor/jszip/')); };
    document.head.appendChild(s);
  });
}

// Cherche une ROM .gba dans l'archive. Lance une erreur lisible sinon.
export async function extractGba(file) {
  const JSZip = await loadJSZip();
  let zip;
  try { zip = await JSZip.loadAsync(file); }
  catch { throw new Error('archive ZIP illisible ou corrompue'); }
  const roms = Object.values(zip.files).filter(e =>
    !e.dir && !e.name.startsWith('__MACOSX') && e.name.toLowerCase().endsWith('.gba'));
  if (!roms.length) throw new Error('aucune ROM .gba dans cette archive');
  const entry = roms[0];
  const blob = await entry.async('blob');
  return { name: entry.name.split('/').pop(), blob, found: roms.length };
}
