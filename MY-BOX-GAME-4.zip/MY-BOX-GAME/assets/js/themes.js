import { storage } from './storage.js';
export const THEMES = [
  { id: 'bleu', label: 'Bleu', preview: 'linear-gradient(90deg,#0b1020,#2563eb)' },
  { id: 'noir', label: 'Noir', preview: 'linear-gradient(90deg,#0a0a0a,#e5e5e5)' },
  { id: 'rouge', label: 'Rouge', preview: 'linear-gradient(90deg,#120708,#c81e2d)' },
  { id: 'blanc', label: 'Blanc', preview: 'linear-gradient(90deg,#f4f6fa,#1e3a8a)' },
  { id: 'degrade', label: 'Dégradé', preview: 'linear-gradient(90deg,#1b1464,#7a1fa2)' }
];
export function applyTheme(id) {
  if (!THEMES.some(t => t.id === id)) id = 'bleu';
  document.documentElement.dataset.theme = id;
  storage.set('theme', id);
  return id;
}
export const initTheme = () => applyTheme(storage.get('theme', 'bleu'));
export const currentTheme = () => document.documentElement.dataset.theme || 'bleu';
