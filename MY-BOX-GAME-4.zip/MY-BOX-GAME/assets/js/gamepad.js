import { storage } from './storage.js';
import { setSourceKeys, getMode, setMode, padActive } from './controls.js';
import { isRunning } from './emulator.js';

export const GBA_KEYS = [['a', 'A'], ['b', 'B'], ['l', 'L'], ['r', 'R'], ['start', 'Start'], ['select', 'Select'],
  ['up', 'Haut'], ['down', 'Bas'], ['left', 'Gauche'], ['right', 'Droite']];
// Correspondance « standard » de la Gamepad API (cercle = A, croix = B).
const DEFAULT_MAP = { a: 1, b: 0, l: 4, r: 5, start: 9, select: 8, up: 12, down: 13, left: 14, right: 15 };
export const getMap = () => ({ ...DEFAULT_MAP, ...storage.get('padMap', {}) });
const setMap = (k, i) => storage.set('padMap', { ...storage.get('padMap', {}), [k]: i });
const resetMap = () => storage.set('padMap', {});

const listeners = new Set();
const subscribe = fn => { listeners.add(fn); return () => listeners.delete(fn); };
const notify = p => listeners.forEach(f => f(p));
export const currentPad = () => [...(navigator.getGamepads?.() || [])].find(p => p && p.connected) || null;
const pressedSet = p => new Set(p ? p.buttons.map((b, i) => b.pressed ? i : -1).filter(i => i >= 0) : []);

let looping = false, last = '';
function loop() {
  const p = currentPad();
  if (!p) { looping = false; setSourceKeys('pad', new Set()); notify(null); return; }
  const keys = new Set();
  if (padActive() && isRunning()) {
    const m = getMap();
    for (const [k] of GBA_KEYS) if (p.buttons[m[k]]?.pressed) keys.add(k);
    const [x = 0, y = 0] = p.axes; // stick gauche = croix directionnelle
    if (x > .5) keys.add('right'); if (x < -.5) keys.add('left');
    if (y > .5) keys.add('down'); if (y < -.5) keys.add('up');
  }
  const sig = [...keys].sort().join();
  if (sig !== last) { last = sig; setSourceKeys('pad', keys); }
  notify(p);
  requestAnimationFrame(loop);
}
const start = () => { if (!looping) { looping = true; requestAnimationFrame(loop); } };

export function initGamepad() {
  if (!navigator.getGamepads) return;
  addEventListener('gamepadconnected', () => { start(); });
  addEventListener('gamepaddisconnected', () => { if (!currentPad()) { setSourceKeys('pad', new Set()); last = ''; notify(null); } });
  if (currentPad()) start();
}

// ---- Page « Manettes » : état, test, correspondances ----
export function initControllerPage(root) {
  const $ = s => root.querySelector(s);
  const mode = $('#mode'), tbl = $('#map'), cells = $('#cells'), axes = $('#axes'), status = $('#padstatus');
  mode.value = getMode(); mode.onchange = () => setMode(mode.value);
  let assigning = null, prev = new Set(), nb = -1;

  const drawMap = () => {
    const m = getMap(); tbl.replaceChildren();
    for (const [k, label] of GBA_KEYS) {
      const row = document.createElement('div'); row.className = 'maprow';
      const n = document.createElement('strong'); n.textContent = label;
      const v = document.createElement('span'); v.className = 'muted';
      v.textContent = assigning === k ? 'Appuyez sur un bouton de la manette…' : 'Bouton ' + m[k];
      const b = document.createElement('button'); b.type = 'button'; b.className = 'btn'; b.textContent = 'Assigner';
      b.onclick = () => { assigning = k; prev = pressedSet(currentPad()); drawMap(); };
      row.append(n, v, b); tbl.append(row);
    }
  };
  $('#reset').onclick = () => { assigning = null; resetMap(); drawMap(); };
  drawMap();

  const render = p => {
    if (!p) {
      status.textContent = "Aucune manette détectée. Branchez-la ou connectez-la, puis appuyez sur un de ses boutons : le navigateur ne la voit qu'après une première pression.";
      cells.replaceChildren(); axes.replaceChildren(); nb = -1; return;
    }
    status.textContent = `Connectée : ${p.id} (${p.mapping === 'standard' ? 'correspondance standard' : 'correspondance non standard : vérifiez les boutons ci-dessous'})`;
    if (nb !== p.buttons.length) {
      nb = p.buttons.length; cells.replaceChildren(); axes.replaceChildren();
      p.buttons.forEach((_, i) => { const c = document.createElement('span'); c.textContent = i; cells.append(c); });
      p.axes.forEach((_, i) => { const m = document.createElement('meter'); m.min = -1; m.max = 1; m.setAttribute('aria-label', 'Axe ' + i); axes.append(m); });
    }
    [...cells.children].forEach((c, i) => c.classList.toggle('on', !!p.buttons[i]?.pressed));
    [...axes.children].forEach((m, i) => { m.value = p.axes[i] ?? 0; });
    if (assigning) {
      const now = pressedSet(p);
      for (const i of now) if (!prev.has(i)) { setMap(assigning, i); assigning = null; drawMap(); break; }
      prev = now;
    }
  };
  const off = subscribe(p => { if (!root.isConnected) return off(); render(p); });
  render(currentPad());
}
