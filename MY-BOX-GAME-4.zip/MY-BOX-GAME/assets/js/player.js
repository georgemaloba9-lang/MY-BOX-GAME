import { gamesDb, savesDb, storage } from './storage.js';
import { applySpeed, getSpeed, getRender, SPEEDS, speedLabel } from './settings.js';
import * as emu from './emulator.js';
import { applyAudio, toggleMute, getAudio } from './audio.js';
import { initControls, releaseAll, touchVisible } from './controls.js';

let run = 0, off = null, ctl = null;
addEventListener('pagehide', () => emu.stopGame());

export async function initPlayer(root) {
  const $ = s => root.querySelector(s);
  const status = $('#status'), screen = $('#screen');
  const say = (t, err) => { status.textContent = t; status.dataset.error = err ? '1' : ''; };
  const token = ++run;

  off?.(); ctl?.destroy(); ctl = null;
  const onLeave = () => {
    if (location.hash.startsWith('#/player')) return;
    run++; releaseAll(); emu.stopGame(); ctl?.destroy(); ctl = null;
    removeEventListener('hashchange', onLeave);
  };
  addEventListener('hashchange', onLeave);
  off = () => removeEventListener('hashchange', onLeave);

  const id = new URLSearchParams(location.hash.split('?')[1] || '').get('id');
  const game = id ? await gamesDb.get(id).catch(() => null) : null;
  if (!game) {
    say('Aucun jeu sélectionné. Choisissez-en un dans la bibliothèque.', true);
    $('#controls').hidden = true; screen.hidden = true; return;
  }
  $('#title').textContent = game.name;
  screen.append(emu.canvas);
  screen.dataset.render = getRender();
  emu.setCrashHandler(() => say("Le moteur a rencontré une erreur et s'est arrêté. Relancez le jeu depuis la bibliothèque.", true));

  emu.setSaveHook((gid, data) => savesDb.put({ id: gid + ':save', gameId: gid, kind: 'save', name: game.name, data, size: data.length, updatedAt: Date.now() }).catch(() => {}));

  // Commandes tactiles
  ctl = initControls($('#touch'));
  const showTouch = touchVisible();
  ctl.setVisible(showTouch);
  $('#edit').hidden = !showTouch;
  const bar = $('#editbar');
  $('#size').value = ctl.cfg.scale; $('#opacity').value = ctl.cfg.opacity;
  $('#size').oninput = e => ctl.setScale(e.target.value);
  $('#opacity').oninput = e => ctl.setOpacity(e.target.value);
  $('#resetpos').onclick = () => { ctl.reset(); $('#size').value = ctl.cfg.scale; $('#opacity').value = ctl.cfg.opacity; };
  $('#edit').onclick = () => { bar.hidden = false; ctl.setEdit(true); bar.scrollIntoView({ block: 'nearest' }); };
  $('#doneedit').onclick = () => { bar.hidden = true; ctl.setEdit(false); };

  const bPause = $('#pause'), bMute = $('#mute'), bFull = $('#full'), bQs = $('#qsave'), bQl = $('#qload');
  const bSpeed = $('#speed');
  const showSpeed = () => { bSpeed.textContent = 'Vitesse ' + speedLabel(getSpeed()); };
  showSpeed();
  bSpeed.onclick = () => {
    storage.set('speed', SPEEDS[(SPEEDS.indexOf(getSpeed()) + 1) % SPEEDS.length]);
    applySpeed(); showSpeed();
  };
  let paused = false;
  const muteLabel = () => { bMute.textContent = getAudio().muted ? 'Son coupé' : 'Son activé'; };
  muteLabel();
  bPause.onclick = () => {
    paused = !paused;
    if (paused) { releaseAll(); emu.pause(); } else emu.resume();
    bPause.textContent = paused ? 'Reprendre' : 'Pause';
    say(paused ? 'Jeu en pause.' : 'Jeu en cours.');
  };
  bMute.onclick = () => { toggleMute(); muteLabel(); };
  bFull.onclick = () => {
    if (document.fullscreenElement) return document.exitFullscreen();
    const f = screen.requestFullscreen || screen.webkitRequestFullscreen;
    if (f) f.call(screen); else say("Le plein écran n'est pas disponible sur ce navigateur.", true);
  };
  bQs.onclick = async () => {
    try {
      const data = await emu.quickSave();
      await savesDb.put({ id: id + ':quick', gameId: id, kind: 'quick', name: game.name, data, size: data.length, updatedAt: Date.now() });
      say('Sauvegarde rapide enregistrée.');
    } catch (e) { say(e.message || 'Sauvegarde rapide impossible.', true); }
  };
  bQl.onclick = async () => {
    const q = await savesDb.get(id + ':quick').catch(() => null);
    if (!q) return say('Aucune sauvegarde rapide pour ce jeu.', true);
    try { await emu.quickLoad(q.data); say('Sauvegarde rapide chargée.'); } catch (e) { say(e.message, true); }
  };
  $('#install').onclick = async () => {
    const b = $('#install'); b.disabled = true;
    try {
      await emu.installEngine(f => say('Téléchargement de ' + f + '…'));
      say('Moteur installé. Rechargement…'); setTimeout(() => location.reload(), 400);
    } catch (e) { say(e.message, true); b.disabled = false; }
  };

  say('Chargement du moteur…');
  try {
    const blob = await gamesDb.rom(id);
    if (!blob) throw new emu.EmulatorError("La ROM n'est plus dans le stockage du navigateur. Réimportez-la depuis la bibliothèque.");
    await emu.initEngine();
    if (token !== run) return;
    const sv = await savesDb.get(id + ':save').catch(() => null);
    await emu.startGame(id, blob, sv?.data);
    if (token !== run) { emu.stopGame(); return; }
    applyAudio(); applySpeed();
    bPause.disabled = bSpeed.disabled = bQs.disabled = bQl.disabled = false;
    say('Jeu en cours.');
    const rs = storage.get('resume');
    if (rs?.gameId === id) {
      storage.set('resume', null);
      if (rs.kind === 'quick') {
        const q = await savesDb.get(id + ':quick').catch(() => null);
        if (q) {
          await new Promise(r => setTimeout(r, 400));
          try { await emu.quickLoad(q.data); say('Sauvegarde rapide chargée.'); } catch (e) { say(e.message, true); }
        }
      }
    }
  } catch (e) {
    console.error(e);
    if (e.code === 'noengine') $('#install').hidden = false;
    say(e instanceof emu.EmulatorError ? e.message : 'Erreur inattendue : ' + (e?.message || e), true);
  }
}
