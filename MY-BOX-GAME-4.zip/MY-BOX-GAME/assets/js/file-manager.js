import { gamesDb } from './storage.js';
import { extractGba } from './zip-handler.js';

const MAX_IMPORT = 128 * 1024 * 1024; // fichier importé
const MAX_ROM = 32 * 1024 * 1024;     // taille maximale d'une ROM GBA
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));
const cleanName = n => n.replace(/\.[^.]+$/, '').replace(/[_]+/g, ' ').trim() || 'Jeu sans titre';

export async function importFiles(files) {
  const results = [];
  const existing = await gamesDb.all().catch(() => []);
  for (const f of files) {
    try { results.push({ file: f.name, game: await importOne(f, existing) }); }
    catch (e) { results.push({ file: f.name, error: e.message }); }
  }
  try { navigator.storage?.persist?.(); } catch {}
  return results;
}

async function importOne(f, existing) {
  const ext = f.name.split('.').pop().toLowerCase();
  if (f.size === 0) throw new Error('fichier vide');
  if (f.size > MAX_IMPORT) throw new Error('fichier trop volumineux (128 Mo maximum)');
  let blob, name = f.name, format;
  if (ext === 'gba') { blob = f; format = 'gba'; }
  else if (ext === 'zip') { const r = await extractGba(f); blob = r.blob; name = r.name; format = 'zip'; }
  else throw new Error('format non pris en charge (.gba ou .zip uniquement)');
  if (blob.size < 192) throw new Error('ROM trop petite pour être valide');
  if (blob.size > MAX_ROM) throw new Error('ROM de plus de 32 Mo : ce n\'est pas une ROM GBA valide');
  if (existing.some(g => g.filename === name && g.size === blob.size)) throw new Error('déjà dans la bibliothèque');
  const meta = { id: uid(), name: cleanName(name), filename: name, format, size: blob.size, addedAt: Date.now(), lastPlayed: null };
  try { await gamesDb.add(meta, blob); }
  catch (e) { throw new Error(e?.name === 'QuotaExceededError' ? 'espace de stockage insuffisant' : 'enregistrement impossible dans ce navigateur'); }
  existing.push(meta);
  return meta;
}
