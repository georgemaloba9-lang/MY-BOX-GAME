export function initAbout(root) {
  const NUM = '0990988313';
  const msg = encodeURIComponent("Bonjour Georges, j'aimerais en savoir plus sur MY BOX_GAME.");
  root.querySelector('#wa').href = `https://wa.me/243990988313?text=${msg}`;
  root.querySelector('#copy').onclick = async () => {
    let ok = false;
    try { await navigator.clipboard.writeText(NUM); ok = true; } catch {}
    const t = document.createElement('div');
    t.className = 'toast'; t.setAttribute('role', 'status');
    t.textContent = ok ? 'Numéro copié' : 'Copie impossible. Numéro : ' + NUM;
    document.body.appendChild(t); setTimeout(() => t.remove(), 2200);
  };
}
