import { gamesDb } from './storage.js';
import { importFiles } from './file-manager.js';

const size = n => n >= 1048576 ? (n / 1048576).toFixed(1) + ' Mo' : Math.ceil(n / 1024) + ' Ko';
const day = t => new Date(t).toLocaleDateString('fr-FR');

export function openGame(id) { location.hash = '#/player?id=' + encodeURIComponent(id); }

export async function initLibrary(root) {
  const $ = s => root.querySelector(s);
  const grid = $('#games'), msg = $('#msg'), q = $('#q'), sort = $('#sort'), input = $('#file');
  let games = [];
  const say = (t, err) => { msg.textContent = t; msg.dataset.error = err ? '1' : ''; };

  async function load() {
    try { games = await gamesDb.all(); }
    catch { games = []; say('Stockage indisponible dans ce navigateur (navigation privée ?).', true); }
    draw();
  }

  function draw() {
    const term = q.value.trim().toLowerCase();
    const list = games.filter(g => g.name.toLowerCase().includes(term));
    const by = {
      recent: (a, b) => b.addedAt - a.addedAt,
      name: (a, b) => a.name.localeCompare(b.name, 'fr'),
      size: (a, b) => b.size - a.size
    }[sort.value];
    list.sort(by);
    grid.replaceChildren();
    if (!games.length) {
      grid.innerHTML = '<div class="empty" style="grid-column:1/-1"><h2>Aucun jeu importé</h2><p class="muted">Importez une ROM .gba ou une archive .zip que vous possédez.</p><button class="btn btn-primary" type="button">Importer un jeu</button></div>';
      grid.querySelector('button').onclick = () => input.click();
      return;
    }
    if (!list.length) { grid.innerHTML = '<p class="muted">Aucun jeu ne correspond à la recherche.</p>'; return; }
    for (const g of list) {
      const c = document.createElement('article');
      c.className = 'card game';
      const h = document.createElement('h3'); h.textContent = g.name;
      const m = document.createElement('p'); m.className = 'muted';
      m.textContent = `${g.format === 'zip' ? 'ZIP (GBA)' : 'GBA'} · ${size(g.size)} · ajouté le ${day(g.addedAt)}`;
      const row = document.createElement('div'); row.className = 'row';
      const play = document.createElement('button'); play.className = 'btn btn-primary'; play.type = 'button'; play.textContent = 'Jouer';
      play.onclick = async () => { await gamesDb.update({ ...g, lastPlayed: Date.now() }).catch(() => {}); openGame(g.id); };
      const del = document.createElement('button'); del.className = 'btn'; del.type = 'button'; del.textContent = 'Supprimer';
      del.setAttribute('aria-label', 'Supprimer ' + g.name);
      del.onclick = async () => {
        if (!confirm(`Supprimer « ${g.name} » de la bibliothèque ?\nSes sauvegardes ne seront pas effacées.`)) return;
        try { await gamesDb.remove(g.id); say(`« ${g.name} » supprimé.`); } catch { say('Suppression impossible.', true); }
        load();
      };
      row.append(play, del);
      c.append(h, m, row);
      grid.append(c);
    }
  }

  $('#import').onclick = () => input.click();
  q.oninput = draw; sort.onchange = draw;
  input.onchange = async () => {
    if (!input.files.length) return;
    say('Importation en cours…');
    const res = await importFiles([...input.files]);
    input.value = '';
    const ok = res.filter(r => r.game).length;
    const bad = res.filter(r => r.error).map(r => `${r.file} : ${r.error}`);
    say([ok ? `${ok} jeu(x) importé(s).` : '', ...bad].filter(Boolean).join('\n'), bad.length > 0);
    load();
  };
  load();
}

export async function initHome(root) {
  let games = [];
  try { games = await gamesDb.all(); } catch {}
  root.querySelector('#count').textContent = games.length === 0 ? 'Aucun jeu importé pour le moment.' : `${games.length} jeu(x) dans votre bibliothèque.`;
  const recent = games.filter(g => g.lastPlayed).sort((a, b) => b.lastPlayed - a.lastPlayed).slice(0, 4);
  const box = root.querySelector('#recent');
  if (!recent.length) return;
  box.replaceChildren();
  for (const g of recent) {
    const b = document.createElement('button');
    b.className = 'btn'; b.type = 'button'; b.textContent = g.name;
    b.onclick = () => openGame(g.id);
    box.append(b);
  }
}
