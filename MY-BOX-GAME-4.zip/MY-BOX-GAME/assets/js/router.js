import { initSettings } from './settings.js';
import { initAbout } from './about.js';
import { initLibrary, initHome } from './library.js';
import { initPlayer } from './player.js';
import { initSaves } from './saves.js';
import { initControllerPage } from './gamepad.js';
const ROUTES = {
  home: initHome, library: initLibrary, player: initPlayer, settings: initSettings,
  controller: initControllerPage, saves: initSaves, about: initAbout
};
const view = () => document.getElementById('view');
export async function render() {
  const name = (location.hash.replace('#/', '') || 'home').split('?')[0];
  const route = name in ROUTES ? name : 'home';
  try {
    const res = await fetch(`pages/${route}.html`);
    if (!res.ok) throw new Error(res.status);
    view().innerHTML = await res.text();
    ROUTES[route]?.(view());
  } catch {
    view().innerHTML = '<div class="empty"><h2>Page introuvable</h2><p class="muted">Lancez le projet depuis un serveur local (voir README.md).</p></div>';
  }
  document.querySelectorAll('.nav a').forEach(a =>
    a.dataset.route === route ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current'));
  document.body.dataset.route = route;
  view().focus({ preventScroll: true });
  window.scrollTo(0, 0);
}
export function startRouter() {
  addEventListener('hashchange', render);
  render();
}
