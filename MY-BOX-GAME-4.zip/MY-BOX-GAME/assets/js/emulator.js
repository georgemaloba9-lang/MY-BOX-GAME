// Intégration du moteur mGBA (WebAssembly, licence MPL-2.0) : @thenick775/mgba-wasm.
// Les fichiers du moteur (mgba.js + mgba.wasm) doivent être dans assets/vendor/emulator/ (voir README.md).
export class EmulatorError extends Error { constructor(msg, code) { super(msg); this.code = code; } }

export const canvas = document.createElement('canvas');
canvas.id = 'mbg-canvas';
canvas.width = 240; canvas.height = 160;
canvas.setAttribute('aria-label', 'Écran du jeu');

let mod = null, booting = null, active = null, syncTimer = null, crashHandler = null;

export const setCrashHandler = fn => { crashHandler = fn; };
let saveHook = null; // appelé avec (idJeu, octets) quand la sauvegarde du jeu change
export const setSaveHook = fn => { saveHook = fn; };
export const isRunning = () => active !== null;

function captureSave() {
  if (!active || !mod) return;
  try { const b = mod.getSave(); if (b && b.length) saveHook?.(active, b.slice()); } catch {}
}
function scheduleSync() {
  clearTimeout(syncTimer);
  syncTimer = setTimeout(() => { captureSave(); mod?.FSSync().catch(() => {}); }, 1500);
}

export function initEngine() {
  return booting ||= (async () => {
    if (!window.crossOriginIsolated)
      throw new EmulatorError("Le moteur a besoin de l'isolation cross-origin (en-têtes COOP/COEP). Lancez le projet avec « python3 serve.py » (voir README.md).", 'isolation');
    let factory;
    try { factory = (await import('../vendor/emulator/mgba.js')).default; }
    catch (e) {
      console.error(e);
      throw new EmulatorError('Moteur introuvable : placez mgba.js et mgba.wasm dans assets/vendor/emulator/, ou installez-le depuis cette page.', 'noengine');
    }
    try {
      const m = await factory({ canvas });
      await m.FSInit();
      m.addCoreCallbacks({
        saveDataUpdatedCallback: scheduleSync,
        coreCrashedCallback: () => { active = null; crashHandler?.(); }
      });
      mod = m;
      return m;
    } catch (e) {
      console.error(e);
      throw new EmulatorError("Le moteur n'a pas pu démarrer : " + (e?.message || e));
    }
  })().catch(e => { booting = null; throw e; });
}

// Copie la ROM (et la sauvegarde du jeu, si on en a une) dans le moteur, puis lance le jeu.
// La sauvegarde utilise un nom unique à chaque lancement : seule notre copie (IndexedDB) fait foi.
export async function startGame(id, blob, saveBytes) {
  const m = await initEngine();
  if (active) stopGame();
  const name = `${id}.gba`;
  await new Promise(res => m.uploadRom(new File([blob], name), res));
  const saveName = `${id}-${Date.now()}.sav`;
  if (saveBytes) await new Promise(res => m.uploadSaveOrSaveState(new File([saveBytes], saveName), res));
  if (!m.loadGame('/data/games/' + name, '/data/saves/' + saveName))
    throw new EmulatorError('Le moteur a refusé cette ROM (fichier invalide ou non pris en charge).');
  active = id;
  return m;
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

// Sauvegarde rapide = état complet du jeu (fonction « auto save state » du moteur).
export async function quickSave() {
  if (!active || !mod) throw new EmulatorError('Aucun jeu en cours.');
  if (!mod.forceAutoSaveState()) throw new EmulatorError("Le moteur n'a pas pu créer la sauvegarde rapide.");
  await sleep(300);
  const st = mod.getAutoSaveState();
  if (!st?.data?.length) throw new EmulatorError("La sauvegarde rapide n'a pas été écrite par le moteur.");
  return st.data.slice();
}
export async function quickLoad(data) {
  if (!active || !mod) throw new EmulatorError('Aucun jeu en cours.');
  await mod.uploadAutoSaveState(mod.autoSaveStateName, new Uint8Array(data));
  if (!mod.loadAutoSaveState()) throw new EmulatorError('Le moteur a refusé cette sauvegarde rapide.');
}

export function pause() { mod?.pauseGame(); mod?.pauseAudio(); }
export function resume() { mod?.resumeGame(); mod?.resumeAudio(); }
export function setVolume(percent) { mod?.setVolume(percent); }
export function setSpeed(multiplier) { mod?.setFastForwardMultiplier(multiplier); }

// Ferme le jeu et libère les ressources (la ROM copiée dans le moteur n'est pas conservée en double).
export function stopGame() {
  if (!active || !mod) return;
  const path = `/data/games/${active}.gba`;
  captureSave();
  active = null;
  try { mod.quitGame(); } catch (e) { console.error(e); }
  try { mod.FS?.unlink?.(path); } catch {}
  mod.FSSync().catch(() => {});
}

export function press(name) { try { mod?.buttonPress(name); } catch {} }
export function release(name) { try { mod?.buttonUnpress(name); } catch {} }

// Installation du moteur depuis un téléphone : télécharge mgba.js / mgba.wasm et les met en cache ;
// le service worker (sw.js) les sert ensuite comme s'ils étaient dans assets/vendor/emulator/.
const ENGINE_URL = 'https://unpkg.com/@thenick775/mgba-wasm@2.3.3/dist/';
export async function installEngine(onStep) {
  if (!navigator.serviceWorker?.controller)
    throw new EmulatorError("Installation impossible : le service worker n'est pas actif (HTTPS ou localhost requis). Rechargez la page.");
  const cache = await caches.open('mbg-engine');
  for (const [f, type] of [['mgba.wasm', 'application/wasm'], ['mgba.js', 'text/javascript']]) {
    onStep?.(f);
    let r;
    try { r = await fetch(ENGINE_URL + f, { mode: 'cors' }); }
    catch { throw new EmulatorError('Téléchargement impossible (connexion ou réseau bloqué).'); }
    if (!r.ok) throw new EmulatorError(`Téléchargement refusé (${r.status}) pour ${f}.`);
    await cache.put('__engine/' + f, new Response(await r.blob(), { headers: { 'Content-Type': type } }));
  }
}
export const getSpeed = () => { try { return mod?.getFastForwardMultiplier(); } catch {} };
