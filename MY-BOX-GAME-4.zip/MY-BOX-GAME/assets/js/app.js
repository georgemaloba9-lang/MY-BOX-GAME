import { initTheme } from './themes.js';
import { startRouter } from './router.js';
import { initGamepad } from './gamepad.js';
initTheme();
initGamepad();
startRouter();
