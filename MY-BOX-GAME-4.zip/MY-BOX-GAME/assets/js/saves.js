import { gamesDb, savesDb, storage } from './storage.js';
import { openGame } from './library.js';

const KIND = { save: 'Sauvegarde du jeu', quick: 'Sauvegarde rapide' };
const size = n => n >= 1048576 ? (n / 1048576).toFixed(1) + ' Mo' : Math.ceil(n / 1024) + ' Ko';

export async function initSaves(root) {
  const $ = s => root.querySelector(s);
  const list = $('#list'), msg = $('#msg'), sel = $('#game'), file = $('#file');
  const say = (t, err) => { msg.textContent = t; msg.dataset.error = err ? '1' : ''; };
  let games = [];

  async function load() {
    let saves = [];
    try { [games, saves] = await Promise.all([gamesDb.all(), savesDb.all()]); }
    catch { say('Stockage indisponible dans ce navigateur.', true); }
    sel.replaceChildren(); games.forEach(g => sel.add(new Option(g.name, g.id)));
    $('#importbox').hidden = !games.length;
    draw(saves.sort((a, b) => b.updatedAt - a.updatedAt));
  }

  function draw(saves) {
    list.replaceChildren();
    if (!saves.length) {
      list.innerHTML = '<div class="empty" style="grid-column:1/-1"><h2>Aucune sauvegarde</h2><p class="muted">Elles apparaissent ici quand vous jouez : sauvegarde du jeu automatique, sauvegarde rapide depuis l\'écran de jeu.</p></div>';
      return;
    }
    for (const s of saves) {
      const exists = games.some(g => g.id === s.gameId);
      const c = document.createElement('article'); c.className = 'card game';
      const h = document.createElement('h3'); h.textContent = s.name;
      const m = document.createElement('p'); m.className = 'muted';
      m.textContent = `${KIND[s.kind]} · ${size(s.size)} · ${new Date(s.updatedAt).toLocaleString('fr-FR')}` + (exists ? '' : ' · jeu supprimé de la bibliothèque');
      const row = document.createElement('div'); row.className = 'row';
      const btn = (label, fn, primary) => {
        const b = document.createElement('button'); b.type = 'button'; b.className = 'btn' + (primary ? ' btn-primary' : '');
        b.textContent = label; b.onclick = fn; row.append(b); return b;
      };
      const play = btn('Reprendre', () => { storage.set('resume', { gameId: s.gameId, kind: s.kind }); openGame(s.gameId); }, true);
      if (!exists) { play.disabled = true; play.title = 'Réimportez la ROM pour reprendre'; }
      btn('Exporter', () => {
        const url = URL.createObjectURL(new Blob([s.data]));
        const a = document.createElement('a'); a.href = url;
        a.download = `${s.name}.${s.kind === 'save' ? 'sav' : 'state'}`.replace(/[\\/:*?"<>|]/g, '_');
        document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
      });
      btn('Supprimer', async () => {
        if (!confirm(`Supprimer cette ${KIND[s.kind].toLowerCase()} de « ${s.name} » ? Cette action est définitive.`)) return;
        try { await savesDb.remove(s.id); say('Sauvegarde supprimée.'); } catch { say('Suppression impossible.', true); }
        load();
      });
      c.append(h, m, row); list.append(c);
    }
  }

  $('#import').onclick = () => file.click();
  file.onchange = async () => {
    const f = file.files[0]; file.value = '';
    if (!f) return;
    const ext = f.name.split('.').pop().toLowerCase();
    const kind = ext === 'sav' ? 'save' : (ext === 'state' || /^ss\d+$/.test(ext)) ? 'quick' : null;
    if (!kind) return say('Format non reconnu : utilisez .sav (sauvegarde du jeu) ou .state (sauvegarde rapide).', true);
    if (f.size === 0 || f.size > (kind === 'save' ? 1048576 : 4194304)) return say('Taille de fichier invalide pour ce type de sauvegarde.', true);
    const g = games.find(x => x.id === sel.value);
    if (!g) return say('Choisissez un jeu.', true);
    const id = g.id + ':' + kind;
    if (await savesDb.get(id).catch(() => null) && !confirm('Une sauvegarde de ce type existe déjà pour ce jeu. La remplacer ?')) return;
    const data = new Uint8Array(await f.arrayBuffer());
    try { await savesDb.put({ id, gameId: g.id, kind, name: g.name, data, size: data.length, updatedAt: Date.now() }); say(`Sauvegarde importée pour « ${g.name} ».`); }
    catch { say('Importation impossible (stockage plein ?).', true); }
    load();
  };
  load();
}
