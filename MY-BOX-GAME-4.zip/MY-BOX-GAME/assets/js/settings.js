import { THEMES, applyTheme, currentTheme } from './themes.js';
import { storage } from './storage.js';
import { getAudio, setMuted, setVolumeLevel } from './audio.js';
import * as emu from './emulator.js';

export const SPEEDS = [1, 1.5, 2, 3];
export const getSpeed = () => storage.get('speed', 1);
export const applySpeed = () => emu.setSpeed(getSpeed());
export const getRender = () => storage.get('render', 'pixel');
export const speedLabel = s => String(s).replace('.', ',') + '×';

export function initSettings(root) {
  const $ = s => root.querySelector(s);
  const say = t => { $('#msg').textContent = t; };

  // Thèmes
  const box = $('#themes');
  const drawThemes = () => {
    box.replaceChildren();
    THEMES.forEach(t => {
      const b = document.createElement('button');
      b.className = 'swatch'; b.type = 'button';
      b.setAttribute('aria-pressed', String(t.id === currentTheme()));
      b.innerHTML = `<i style="background:${t.preview}"></i>${t.label}`;
      b.onclick = () => { applyTheme(t.id); drawThemes(); };
      box.append(b);
    });
  };
  drawThemes();

  // Son
  const a = getAudio();
  $('#sound').checked = !a.muted;
  $('#sound').onchange = e => setMuted(!e.target.checked);
  $('#volume').value = a.volume; $('#volval').textContent = a.volume + ' %';
  $('#volume').oninput = e => { setVolumeLevel(+e.target.value); $('#volval').textContent = e.target.value + ' %'; };

  // Vitesse (agit sur le moteur : multiplicateur d'avance rapide de mGBA)
  const sp = $('#speed');
  SPEEDS.forEach(s => sp.add(new Option(speedLabel(s), s)));
  sp.value = getSpeed();
  sp.onchange = () => { storage.set('speed', +sp.value); applySpeed(); };

  // Commandes tactiles (taille, transparence, positions)
  const cfg = () => storage.get('touchCfg', {});
  $('#tsize').value = cfg().scale ?? 1;
  $('#topac').value = cfg().opacity ?? 0.7;
  $('#tsize').oninput = e => storage.set('touchCfg', { ...cfg(), scale: +e.target.value });
  $('#topac').oninput = e => storage.set('touchCfg', { ...cfg(), opacity: +e.target.value });
  $('#tpos').onclick = () => { storage.set('touchCfg', { ...cfg(), pos: {} }); say('Positions des boutons réinitialisées.'); };

  // Affichage
  $('#render').value = getRender();
  $('#render').onchange = e => storage.set('render', e.target.value);
}
