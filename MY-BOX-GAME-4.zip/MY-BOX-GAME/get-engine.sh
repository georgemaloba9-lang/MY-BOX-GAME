#!/bin/sh
# Télécharge le moteur mGBA WebAssembly (@thenick775/mgba-wasm) dans assets/vendor/emulator/
set -e
cd "$(dirname "$0")"
TMP=$(mktemp -d)
( cd "$TMP" && npm pack @thenick775/mgba-wasm@2.3.3 --silent && tar xzf ./*.tgz )
cp "$TMP"/package/dist/mgba.js "$TMP"/package/dist/mgba.wasm assets/vendor/emulator/
cp "$TMP"/package/LICENSE* assets/vendor/emulator/ 2>/dev/null || true
rm -rf "$TMP"
echo "Moteur installé dans assets/vendor/emulator/"
ls -l assets/vendor/emulator/
